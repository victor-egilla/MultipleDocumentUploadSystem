﻿
let defaultDate = '1900-01-01';

$(document).ready(function () {
    getAllCountries();
    getAllCities();
    getAllStates();

    getAllSalesRecords();
    $("#filterBtn").on("click", getAllSalesRecords);
    $("#ResetBtn").on("click", ResetFilter);

    $("#closeModalBtn").on("click", () => {
        $("#salesModal").modal("hide")
    });
});

var initialSalesTable = 0;
var salesTable = "";


async function getAllSalesRecords() {
    emptyTable();
    
    salesTable = $("#salesTbl").DataTable({
        "lengthMenu": [[10, 25, 50, 100, 200, 300, 400, 500 - 1], [10, 25, 50, 100, 200, 300, 400, 500, "All"]],
        "processing": true,
        serverSide: true,
        ajax: {
            url: apiBaseUrl + `Sales/GetAllSales`,
            type: 'POST',
            //headers: {
            //    //'Authorization': `Bearer ${localStorage.getItem("userToken")}`,
            //},
            "contentType": 'application/json; charset=utf-8',
            data: function (D) {

                let dataToSend = {
                    "draw": D.draw,
                    "start": D.start,
                    "length": D.length,
                    "search": D.search.value,
                    "Date": $("#searchDate").val() == "" ? defaultDate : $("#searchDate").val(),
                    "CountryCode": ($("#searchCountry").val() == null ? "" : $("#searchCountry").val()),
                    "State": ($("#searchState").val() == null ? "" :$("#searchState").val()),
                    "CityCode": ($("#searchCity").val() == null ? 0 : parseInt($("#searchCity").val()))
                };
                
                return JSON.stringify(dataToSend);
            }
        },
        "columns": [
            {
                "render": function (data, type, row) {
                    return row.CustomerName;
                }
            },
            {
                "render": function (data, type, row) {
                    return row.ProductName;
                }
            },
            {
                "render": function (data, type, row) {
                    return row.CountryName;
                }
            },
            {
                "render": function (data, type, row) {
                    return row.RegionName;
                }
            },
            {
                "render": function (data, type, row) {
                    return row.CityName;
                }
            },
            {
                "render": function (data, type, row) {
                    return (moment(row.DateOfSale).format("Do MMMM, YYYY"))
                }
            },
            {
                "render": function (data, type, row) {
                    return `<a id="viewClaims" type="button" onclick = "viewSales(${row.SalesID},'${row.ProductName}')" class='btn btn-sm btn-primary px-3'><i class="fa fa-eye"></i>&nbsp;View Sale</a>
                        `
                }/*"getWord(${row.WordId}, ${row.StatusId}, 'view')"*/
            },
        ],
        "drawCallback": function () {
            initialSalesTable++;
        },
        dom: 'Bfrtip',
        ordering: false,
        "scrollX": true,
        responsive: true,
        buttons: [],
        columnDefs: [{ "defaultContent": "-", "targets": "_all" }]
    });
}


function ResetFilter() {
    $('input[type=date]').val('');
    $('select').val('0');
    getAllSalesRecords();
}

function emptyTable() {
    if (initialSalesTable > 0) {
        salesTable.destroy();
    }
    if ($("#salesTbl tbody").find("tr").length > 0) {
        $("#salesTbl tbody").empty();
    }
    initialSalesTable = 0;
}

async function viewSales(salesId, productName) {
    openModal("#salesModal");

    await ajaxAsync(`Sales/GetSalesDetailsBySalesId/${salesId}`, {}, "GET", (data) => {
        
        if (data.responseCode == "00") {
            var sale = data.responseData[0];
            $("#modalTitle").text(productName);

            $("#wait_img").addClass("hide");
            $("#cName").text(sale.CustomerName);
            $("#cityName").text(sale.CityName);
            $("#productName").text(sale.ProductName);
            $("#countryName").text(sale.CountryName);
            $("#regionName").text(sale.RegionName);
            $("#price").text(sale.Price);
            $("#saleDate").text((moment(sale.DateOfSale).format("Do MMMM, YYYY")));
        }
        else {
            alert(data.responseMessage);
            $("#closeModalBtn").on("click", () => {
                $("#salesModal").modal("hide")
            });
            $("#wait_img").addClass("hide");
        }
    }, () => {
        alert(data);
        $("#wait_img").addClass("hide");
    }, () => {
        alert(data);
        $("#wait_img").addClass("hide");
    });
}