﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ABC_Company_Solution.Helper_Classes
{
    public static class Utilities
    {
        public enum ResponseCode
        {
            Success = 00,
            Empty = 02,
            Failure = 03
        }
    }
}
