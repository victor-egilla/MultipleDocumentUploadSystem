﻿using ABC_Company_Solution.Helper_Methods;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ABC_Company_Solution.Helper_Classes
{
    public class HelperMethods
    {
        private readonly ErrorLogger _logger;
        private readonly string _connectionString;

        public HelperMethods(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _logger = new ErrorLogger(_Destination: @"ErrorLogs");
        }
        public async Task<dynamic> LogError(string errorInfo)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ErrorInfo", errorInfo);

                    var response = await SqlMapper.QueryAsync<dynamic>(con, "sp_LogError", param, commandType: CommandType.StoredProcedure);
                    var responseCode = response.Select(x => x.Response).FirstOrDefault();
                    return responseCode;
                }
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex);
                return false;
            }
        }
    }
}
