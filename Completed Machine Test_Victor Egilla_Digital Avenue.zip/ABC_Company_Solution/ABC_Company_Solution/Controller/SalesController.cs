﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ABC_Company_Solution.Interfaces;
using ABC_Company_Solution.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ABC_Company_Solution.Controller
{
    [Route("[controller]")]
    [ApiController]
    public class SalesController : ControllerBase
    {
        private readonly ISalesRepository _repo;

        public SalesController(ISalesRepository repo)
        {
            _repo = repo;
        }

        [HttpGet("GetDropDownData/{TableType}/{QueryId}")]
        public async Task<IActionResult> GetDropDownData([FromRoute]int TableType, string QueryId)
        {
            var data = await _repo.GetDropDownData(TableType, QueryId);
            if (data.ResponseCode == "00")
                return Ok(data);
            else
                return BadRequest(data);
        }


        //ADD SALES INFO
        [HttpPost("AddSales")]
        public async Task<IActionResult> AddSales([FromBody]AddSalesModel payload)
        {
            var add = await _repo.AddSalesInventory(payload);
            if (add.ResponseCode == "00")
                return Ok(add);
            else
                return BadRequest(add);
        }


        //GET SALES INFO
        [HttpPost("GetAllSales")]
        public async Task<IActionResult> GetAllSales([FromBody]ParamFetchSales payload)
        {
            var sales = await _repo.GetAllSales(payload);
            if (sales.ResponseCode == "00")
                return Ok(sales);
            else
                return BadRequest(sales);
        }

        //GET SALES DETAILS
        [HttpGet("GetSalesDetailsBySalesId/{SalesId}")]
        public async Task<IActionResult> GetSalesDetailsBySalesId([FromRoute] int SalesId)
        {
            var data = await _repo.GetSalesDetailsBySalesId(SalesId);
            if (data.ResponseCode == "00")
                return Ok(data);
            else
                return BadRequest(data);
        }
    }
}
